<?php

// Include Cuztom
require_once dirname(__FILE__).'/src/Cuztom.php';
