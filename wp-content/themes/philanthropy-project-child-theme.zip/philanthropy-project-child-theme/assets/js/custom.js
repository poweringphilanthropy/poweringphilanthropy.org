jQuery(document).ready(function(){
    var result = jQuery("#charitable_field_goal").hasClass("even");
    //alert(result);
    if(result == true){
     
        jQuery("#charitable_field_goal").removeClass("even").addClass("odd");
    }else{
       
    }
	
	var result = jQuery("#charitable_field_end_date").hasClass("odd");
   // alert(result);
    if(result == true){
     
        jQuery("#charitable_field_end_date").removeClass("odd").addClass("even");
    }else{
       
    }
	
	jQuery('.subject-list').on('change', function() {

		jQuery('.subject-list').not(this).prop('checked', false);  

	});
	
	
});
