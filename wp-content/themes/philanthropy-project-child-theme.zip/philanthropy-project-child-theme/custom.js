jQuery(document).ready(function(){
    var result = jQuery("#charitable_field_goal").hasClass("even");
    alert(result);
    if(result == true){
     
        jQuery(this).removeClass("even").addClass("odd");
    }else{
       
    }
});
